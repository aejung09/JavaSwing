package shareVar;

public class ShareVar {
	
	public static final String url_mysql = "jdbc:mysql://127.0.0.1/mproject?serverTimezone=UTC&characterEncoding=utf8&useSSL=FALSE";
    public static final String id_mysql = "root";
    public static final String pw_mysql = "qwer1234";

    public static String nowid; 
    public static String nowname; 
    public static String nowpw; 
    public static String nowemail; 
    public static String nowusercode;
    public static String wkseq;
    public static String wkname;
    public static String boardusercode;
    public static String userstatus;
    public static String nowemailaddress;
    
    public static int filename = 0;
    
    public static String nowphcode;
    public static String nowmcode;
    public static int nowlikecount;
    
    
     	
}
