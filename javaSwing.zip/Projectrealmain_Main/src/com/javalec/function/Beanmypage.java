package com.javalec.function;

public class Beanmypage {

	String mcode;
	String usercode;
	String phcode;
	int seqno;
	
	
	
	String category;
	String title;
	String date;
	String id;
	
	String pname;
	String address;
	String tel;
	
	String mname;
	String ingredient;
	String effect;
	
	String user;
	String text;
	
	public Beanmypage() {
		
	}
	
	
	
//	int seqno;
//	String category;
//	String title;
//	String date;
	
	
	
	



	
	public Beanmypage(int seqno, String category, String title, String text) {
		super();
		this.seqno= seqno;
		this.category = category;
		this.title = title;
		this.text = text;
	}

	public Beanmypage(String category, String title, String text) {
		super();
		this.category = category;
		this.title = title;
		this.text = text;
	}



//	public Beanmypage(int seqno, String category, String title, String date, String user) {
//		super();
//		this.seqno = seqno;
//		this.category = category;
//		this.title = title;
//		this.date = date;
//		this.user=user;
//		}



	public int getSeqno() {
		return seqno;
	}



	public void setSeqno(int seqno) {
		this.seqno = seqno;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getDate() {
		return date;
	}



	public void setDate(String date) {
		this.date = date;
	}



	public String getUser() {
		return user;
	}



	public void setUser(String user) {
		this.user = user;
	}



	public String getText() {
		return text;
	}



	public void setText(String text) {
		this.text = text;
	}
}


////
////	
////	
////	
////	
////	
////	
////	
////	
////	
////
////	public Beanmypage(int seqno, String category, String title, String date, String id) {
////		super();
////		this.seqno = seqno;
////		this.category = category;
////		this.title = title;
////		this.date = date;
////		this.id = id;
////	}
////
////
////
////
////
////
////
////
////
////
////
////
////
////
////	public Beanmypage(String pname, String address, String tel) {
////		super();
////		this.pname = pname;
////		this.address = address;
////		this.tel = tel;
////	}
////
////
////
////
////
////
////
////
////
////
////
////
//////
//////
//////	public Beanmypage(String mname, String ingredient, String effect) {
//////		super();
//////		this.mname = mname;
//////		this.ingredient = ingredient;
//////		this.effect = effect;
//////	}
////
////
////
////
////
////
////
////
////
////
////
////
////
////
////	public int getMcode() {
////		return mcode;
////	}
////
////	public void setMcode(int mcode) {
////		this.mcode = mcode;
////	}
////
////	public int getUsercode() {
////		return usercode;
////	}
////
////	public void setUsercode(int usercode) {
////		this.usercode = usercode;
////	}
////
////	public int getPhcode() {
////		return phcode;
////	}
////
////	public void setPhcode(int phcode) {
////		this.phcode = phcode;
////	}
////
////	public int getSeqno() {
////		return seqno;
////	}
////
////	public void setSeqno(int seqno) {
////		this.seqno = seqno;
////	}
////
////	public String getCategory() {
////		return category;
////	}
////
////	public void setCategory(String category) {
////		this.category = category;
////	}
////
////	public String getTitle() {
////		return title;
////	}
////
////	public void setTitle(String title) {
////		this.title = title;
////	}
////
////	public String getDate() {
////		return date;
////	}
////
////	public void setDate(String date) {
////		this.date = date;
////	}
////
////	public String getId() {
////		return id;
////	}
////
////	public void setId(String id) {
////		this.id = id;
////	}
////
////	public String getPname() {
////		return pname;
////	}
////
////	public void setPname(String pname) {
////		this.pname = pname;
////	}
////
////	public String getAddress() {
////		return address;
////	}
////
////	public void setAddress(String address) {
////		this.address = address;
////	}
////
////	public String getTel() {
////		return tel;
////	}
////
////	public void setTel(String tel) {
////		this.tel = tel;
////	}
////
////	public String getMname() {
////		return mname;
////	}
////
////	public void setMname(String mname) {
////		this.mname = mname;
////	}
////
////	public String getIngredient() {
////		return ingredient;
////	}
////
////	public void setIngredient(String ingredient) {
////		this.ingredient = ingredient;
////	}
////
////	public String getEffect() {
////		return effect;
////	}
////
////	public void setEffect(String effect) {
////		this.effect = effect;
////	}
////	
////	
////	
////
////
////
////
////	
//
//	
//
//}

